python detect.py  --weights best.pt  --source inference/images  --img-size 640  --conf-thres 0.6 --iou-thres 0.6   --device 0 --save-txt  --save-conf 

# To replace the images in the "inference/images" directory that you want to analyze, and then run the above code.
# If you want understand our network frame，you can reference ''cfg/depoly/bhb-6heads-config.yaml''.
# You may need to configure your local  environment according to the requirements.txt file.
